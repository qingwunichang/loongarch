/* Generated automatically. */
static const char configuration_arguments[] = "/opt/loongarch32r-linux-gnusf-2022-05-20/gcc-8.3.0/src/configure --target=loongarch32r-linux-gnusf --enable-shared --disable-bootstrap --disable-emultls --enable-tls --enable-languages=c,c++,fortran --enable-initfini-array --enable-gnu-indirect-function --prefix=/opt/loongarch32r-linux-gnusf-2022-05-20/ --with-gmp=/opt/loongarch32r-linux-gnusf-2022-05-20/ --with-mpfr=/opt/loongarch32r-linux-gnusf-2022-05-20/ --with-mpc=/opt/loongarch32r-linux-gnusf-2022-05-20/ --with-sysroot=/opt/loongarch32r-linux-gnusf-2022-05-20//sysroot --with-build-time-tools=/opt/loongarch32r-linux-gnusf-2022-05-20//loongarch32r-linux-gnusf/bin";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "ilp32s" }, { "arch", "loongarch32r" }, { "tune", "loongarch32r" }, { "fpu", "none" } };
